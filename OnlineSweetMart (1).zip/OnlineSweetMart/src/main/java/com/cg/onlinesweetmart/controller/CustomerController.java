package com.cg.onlinesweetmart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.onlinesweetmart.dao.CustomerDao;
import com.cg.onlinesweetmart.exception.CustomerAlreadyExistsException;
import com.cg.onlinesweetmart.exception.CustomerCreationException;
import com.cg.onlinesweetmart.exception.NoSuchCustomerFoundException;
import com.cg.onlinesweetmart.model.Customer;

@CrossOrigin("*")
@RestController
public class CustomerController {
	
	
	@Autowired
	CustomerDao dao;
	

		
	
	@PostMapping(path = "add/customer")
	public Customer addCustomer(@RequestBody Customer customer) throws CustomerAlreadyExistsException, CustomerCreationException
	{
		Customer b=dao.addCustomer(customer);
		if(b!=null)
		{
			
			System.out.println("Customer is created");
		}
		else
		{
			System.out.println("not able to create book object");
		}
		return b;
		
	}
	
	@GetMapping(path = "customer")
	public Customer getCustomers()
	{
		
		return dao.viewCustomer(); 
		
	}
	

	@GetMapping(path="fetch/customer/{customerId}")
	public Customer extractCustomerById(@PathVariable int customerId) throws NoSuchCustomerFoundException{
		return dao.extractCustomerById(customerId);
	}

	@DeleteMapping(path="deletecustomer/{id}")
	public Customer deleteCustomer(@PathVariable int id) throws NoSuchCustomerFoundException{
		//logger.info("Flight details removed from the database");
		return dao.deleteCustomer(id);
	}

	@PutMapping(path="Update/customer/{customerId}") 
public Customer updateCustomer(@RequestBody Customer customer, @PathVariable int customerId) throws NoSuchCustomerFoundException {
		
		return this.dao.updateCustomer(customer,customerId);		
	
		}
	}
