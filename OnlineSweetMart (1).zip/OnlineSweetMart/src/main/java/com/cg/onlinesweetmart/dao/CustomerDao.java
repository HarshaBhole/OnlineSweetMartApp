package com.cg.onlinesweetmart.dao;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.onlinesweetmart.exception.CustomerAlreadyExistsException;
import com.cg.onlinesweetmart.exception.NoSuchCustomerFoundException;
import com.cg.onlinesweetmart.model.Customer;
import com.cg.onlinesweetmart.repository.CustomerRepository;
import com.cg.onlinesweetmart.service.CustomerService;

@Service
public class CustomerDao implements CustomerService {

	@Autowired
	private CustomerRepository rep;

	Logger logger = org.slf4j.LoggerFactory.getLogger(CustomerDao.class);

	@Override
	public Customer addCustomer(Customer customer) throws CustomerAlreadyExistsException {

		if (rep.existsById(customer.getCustomerId())) {
			logger.error("Customer already exists exception");
			throw new CustomerAlreadyExistsException("Customer already exists");
		} else {
			logger.info("Customer added successfully");
			return rep.save(customer);
		}

	}

	@Override
	public Customer viewCustomer() {
		// TODO Auto-generated method stub
		List<Customer> list = rep.findAll();
		for (Customer c : list)
			logger.info(c.getCustomerId() + " " + c.getCustomerName() + " " + c.getCustomerMobile() + " "
					+ c.getCustomerEmail() + "" + c.getCustomerAddress());
		return null;

	}

	@Override
	public Customer deleteCustomer(int customerId) throws NoSuchCustomerFoundException {
		rep.delete(rep.getById(customerId));
		return null;
	}

	@Override
	public Customer updateCustomer(Customer customer, int customerId) throws NoSuchCustomerFoundException {

		Optional<Customer> optional = rep.findById(customer.getCustomerId());
		if (optional.isPresent()) {
			rep.save(customer);
			return customer; // returns updated loan application
		} else {
			throw new NoSuchCustomerFoundException("Customer Data couldn't be Updated! ");
		}
	}

	public Customer findbyid(int id) throws NoSuchCustomerFoundException {
		return rep.findById(id).orElseThrow(() -> new NoSuchCustomerFoundException("customer does not exist"));
	}

	@Override
	public Customer extractCustomerById(int customerId) throws NoSuchCustomerFoundException {

		Optional<Customer> found = rep.findById(customerId);
		if (found.isPresent()) {
			return found.get();
		} else {
			throw new NoSuchCustomerFoundException("This Customer does not exist");
		}
	}
}