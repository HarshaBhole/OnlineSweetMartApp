package com.cg.onlinesweetmart.controller;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.onlinesweetmart.dao.OrderBillDao;
import com.cg.onlinesweetmart.exception.NoSuchOrderBillException;
import com.cg.onlinesweetmart.exception.OrderBillAlreadyExistsException;
import com.cg.onlinesweetmart.model.OrderBill;

@CrossOrigin("*")

//tell tht spring boot application tht http req is handled by this cls
 @RestController
 
 //maps a specific req to controller
// @RequestMapping("/OrderBill")
 
public class OrderBillController {

	 	Logger logger = org.slf4j.LoggerFactory.getLogger(OrderBillController.class);
 
	@Autowired
	 private OrderBillDao orderBillDao;
	
	
    @PostMapping(path="add/OrderBill")
	public OrderBill addorderBill(@Valid@RequestBody OrderBill orderBill)throws OrderBillAlreadyExistsException
	{
    	 logger.info("OrderBill added to the database");
		return orderBillDao.addOrderBill(orderBill);
	}
	
	
    @PutMapping(path = "update/OrderBill/{orderBillId}")
	public OrderBill updateOrderBill(@RequestBody @Valid OrderBill orderbill,@PathVariable int orderBillId)throws NoSuchOrderBillException
	{
		 logger.info("OrderBill details modified successfully");
		return orderBillDao.UpdateOrderBill(orderbill);
	}

	
	@GetMapping(path="fetch/OrderBill/{orderBillId}")
	public OrderBill getOrderBillById(@PathVariable int orderBillId) {
	return orderBillDao.extractOrderBillById(orderBillId);	
	}
	
	@DeleteMapping(path = "cancel/OrderBill/{orderBillId}") 
	public OrderBill cancelOrderBill(@PathVariable int orderBillId) throws NoSuchOrderBillException
	{
	    
		logger.info("Order details removed from the database");
		return orderBillDao.cancelOrderBill(orderBillId);
	}
	
	
	@GetMapping(path="get/All/OrderBills")
	public List<OrderBill> showAllOrderBills() 
	{
		return orderBillDao.showAllOrderBills();
	}

	
}