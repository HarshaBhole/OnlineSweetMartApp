package com.cg.onlinesweetmart.exception;

public class SweetOrderAlreadyExistsException extends Exception {
	public SweetOrderAlreadyExistsException(String str) {
		super(str);
	}

}