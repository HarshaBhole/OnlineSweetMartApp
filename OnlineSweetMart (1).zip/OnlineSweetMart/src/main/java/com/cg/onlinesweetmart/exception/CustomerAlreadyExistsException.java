package com.cg.onlinesweetmart.exception;

public class CustomerAlreadyExistsException extends Exception {

/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public CustomerAlreadyExistsException(String str) {
        super(str);
	}
}