package com.cg.onlinesweetmart.controller;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.cg.onlinesweetmart.dao.AdminDao;
//import com.cg.onlinesweetmart.exception.AdminIdAlreadyExistsException;
//import com.cg.onlinesweetmart.exception.AdminNotFoundException;
//import com.cg.onlinesweetmart.model.Admin;
//@RestController
//@RequestMapping("/admin")
//public class AdminController {
//	Logger logger =  LoggerFactory.getLogger(AdminController.class);
//
//	@Autowired
//	private AdminDao adminDao;
//
//	@PostMapping(path = "/addAdmin")
//	public Admin addAdmin(@RequestBody Admin admin) throws AdminIdAlreadyExistsException {
//		logger.info("Admin added to the database");
//		return adminDao.addAdmin(admin);
//	}
//
//	@DeleteMapping(path ="/removeAdmin/{Id}")
//	public void removeAdmin(@PathVariable String Id) throws AdminNotFoundException {
//		logger.info("Admin removed from the database");
//		adminDao.removeAdmin(Id);
//	}
//
//}
