package com.cg.onlinesweetmart.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.onlinesweetmart.model.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer> {
	@Transactional
	@Modifying
	@Query(value = "delete from Customer c where c.customerId=?1")
	public int deleteCustomerById(int id);
	@Query(value = "select c from customer_table c where c.customer_Id=?1", nativeQuery = true)
	public Customer getCustomerById(int customerId);

	@Query(value = "update  Customer_Table  set customer_Name =?1,customer_Address=?2 ,customer_Mobile=?3,customer_Email=?4 where customer_Id=?5", nativeQuery = true)
	public int updateCustomerBycId(int cId, String cName, long cMobile, String cEmail, String cAddress);

}
