package com.cg.onlinesweetmart.exception;

public class NoSuchProductFoundException extends Exception {

	public NoSuchProductFoundException() {
		super();
	}

	public NoSuchProductFoundException(String errorMsg) {
		super(errorMsg);
	}
}