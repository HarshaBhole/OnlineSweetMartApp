package com.cg.onlinesweetmart.dao;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.onlinesweetmart.exception.CategoryAlreadyExistsException;
import com.cg.onlinesweetmart.exception.NoSuchCategoryException;
import com.cg.onlinesweetmart.model.Category;
import com.cg.onlinesweetmart.repository.CategoryRepository;
import com.cg.onlinesweetmart.service.CategoryService;
@Service
public class CategoryDao implements CategoryService{

	@Autowired 
  private  CategoryRepository rep;

	
	Logger logger=org.slf4j.LoggerFactory.getLogger(CategoryDao.class);
	
	 

		
		@Override
		
		public Category addCategory(Category c)throws CategoryAlreadyExistsException {
			
			

				if (rep.existsById(c.getCategoryId())) {
					logger.error("Category had already registered ");
					throw new CategoryAlreadyExistsException("category already exists ");
				} else {
					logger.info("category added successfully");
					return rep.save(c);
				}
		
			
		}
		
	
	@Override
	public Category cancelCategory(int categoryId) throws NoSuchCategoryException{
		// TODO Auto-generated method stub
		Optional<Category> c = rep.findById(categoryId);  
        Category  c1 = null;          
        if (c.isPresent()) {
            c1 = c.get();                  
            rep.delete(c1);
        }else {
            throw new NoSuchCategoryException("No such category Exists");
        }  
        return c1;
	}

	@Override
	public Category updateCategory(Category category)
  	{
		
		int status=0;
		int cgId=category.getCategoryId();
		String name=category.getName();
		status=rep.updatedCategoryByCgId(name,cgId);
		if(status>=1) {
			return category;
		}else {
		return null;
		}
	}
	@Override
	public List<Category> showAllCategorys() {
		// TODO Auto-generated method stub
		return rep.findAll();
	}

	@Override
	public double calculateTotalCost(int categoryId) {
		// TODO Auto-generated method stub
	return rep.calculateTotalCost(categoryId);
	}


	@Override
	public Category extractCategoryById(int categoryId) {
		// TODO Auto-generated method stub
		return rep.findById(categoryId).get();
	}

}