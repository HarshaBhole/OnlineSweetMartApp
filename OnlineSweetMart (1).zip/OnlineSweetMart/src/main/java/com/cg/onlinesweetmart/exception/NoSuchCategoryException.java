package com.cg.onlinesweetmart.exception;

public class NoSuchCategoryException extends Exception {
	public NoSuchCategoryException(String str) {
		super(str);
	}
}