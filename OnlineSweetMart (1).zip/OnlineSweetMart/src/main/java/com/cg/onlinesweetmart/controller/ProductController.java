package com.cg.onlinesweetmart.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.onlinesweetmart.dao.ProductDao;
import com.cg.onlinesweetmart.exception.NoSuchProductFoundException;
import com.cg.onlinesweetmart.exception.ProductAlreadyExistsException;
import com.cg.onlinesweetmart.model.Product;

@CrossOrigin("*")
@RestController
//@RequestMapping("/Product")
public class ProductController {

	Logger logger = org.slf4j.LoggerFactory.getLogger(ProductController.class);

	@Autowired
	private ProductDao productdao;

	@PostMapping(path = "add/Product")
	public Product addProduct(@Valid @RequestBody Product product) throws ProductAlreadyExistsException {

		return productdao.addProduct(product);

	}

	@PutMapping(path = "update/product/{productId}")
	public Product updateProduct(@RequestBody @Valid Product product, @PathVariable int productId)
			throws NoSuchProductFoundException {
		logger.info("Updated The Product Details");
		return productdao.updateProduct(product);
	}

	@GetMapping(path = "fetch/product/{productId}")
	public Product getproductById(@PathVariable int productId) {
		return productdao.extractProductById(productId);
	}

	@DeleteMapping(path = "cancel/Product/{productId}")

	public Product cancelProduct(@PathVariable int productId) throws NoSuchProductFoundException {

		return productdao.cancelProduct(productId);

	}

	@GetMapping(path = "get/All/Products")
	public List<Product> showAllProducts() {

		return productdao.showAllProducts();
	}

}