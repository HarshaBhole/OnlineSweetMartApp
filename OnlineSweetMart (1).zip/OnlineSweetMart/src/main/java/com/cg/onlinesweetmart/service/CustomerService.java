package com.cg.onlinesweetmart.service;

import com.cg.onlinesweetmart.exception.CustomerAlreadyExistsException;
import com.cg.onlinesweetmart.exception.NoSuchCustomerFoundException;
import com.cg.onlinesweetmart.model.Customer;

public interface CustomerService {

	public Customer addCustomer(Customer c) throws CustomerAlreadyExistsException;

	public Customer viewCustomer();

	public Customer deleteCustomer(int customerId) throws NoSuchCustomerFoundException;

	public Customer extractCustomerById(int customerId) throws NoSuchCustomerFoundException;

	public Customer updateCustomer(Customer customer, int customerId) throws NoSuchCustomerFoundException;

}