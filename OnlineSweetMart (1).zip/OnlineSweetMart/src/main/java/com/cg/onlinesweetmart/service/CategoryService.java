package com.cg.onlinesweetmart.service;

import java.util.List;

import com.cg.onlinesweetmart.exception.CategoryAlreadyExistsException;
import com.cg.onlinesweetmart.exception.NoSuchCategoryException;
import com.cg.onlinesweetmart.exception.NoSuchCategoryFoundException;
import com.cg.onlinesweetmart.model.Category;

public interface CategoryService {
	public Category addCategory(Category category) throws CategoryAlreadyExistsException;

	public Category updateCategory(Category category) throws NoSuchCategoryFoundException;

	public Category cancelCategory(int categoryId) throws NoSuchCategoryException;

	public List<Category> showAllCategorys();

	public double calculateTotalCost(int categoryId);

	public Category extractCategoryById(int categoryId);
}