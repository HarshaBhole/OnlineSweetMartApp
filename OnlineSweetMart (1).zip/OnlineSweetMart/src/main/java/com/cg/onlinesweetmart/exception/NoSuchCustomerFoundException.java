package com.cg.onlinesweetmart.exception;
public class NoSuchCustomerFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoSuchCustomerFoundException(String str) {
        super(str);
	}
}