package com.cg.onlinesweetmart.service;
import java.util.List;

import com.cg.onlinesweetmart.exception.NoSuchUserFoundException;
import com.cg.onlinesweetmart.exception.UserAlreadyExistsException;
import com.cg.onlinesweetmart.model.User;


//
//import com.cg.onlinesweetmart.exception.NoSuchUserFoundException;
//import com.cg.onlinesweetmart.exception.UserAlreadyExistsException;

public interface UserService {
	public User addUser(User user) throws UserAlreadyExistsException;

	public User updateUser(User user);

	public User cancelUser(Long userId) throws NoSuchUserFoundException;

	List<User> showAllUsers();

	public User extractUserById(Long userId);

	public User getLogin(String userName, String password, String passwordConfirm);

}