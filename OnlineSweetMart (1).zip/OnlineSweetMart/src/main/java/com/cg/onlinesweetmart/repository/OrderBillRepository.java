package com.cg.onlinesweetmart.repository;
 
import java.time.LocalDate;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.onlinesweetmart.model.OrderBill;


@Repository
public interface OrderBillRepository extends JpaRepository<OrderBill, Integer> {


	@Query(value= "select o.orderBill_orderBillId from orderBill_table o inner join sweetOrder_table so on so.orderBill_id=o.orderBill_id where so.sweetOrder_id=?1", nativeQuery=true)
	public String getOrderBillId(int orderBillId);
	
	@Query(value= "select o.orderBill_createdDate from orderBill_table o inner join sweetOrder_table so on so.orderBill_createdDate=o.orderBill_createdDate where so.sweetOrder_id=?1", nativeQuery=true)
	public LocalDate getcreatedDate(LocalDate createdDate);
	

	@Query(value= "select o.orderBill_totalCost from orderBill_table o inner join sweetOrder_table so on so.orderBill_totalCost=o.orderBill_totalCost where so.sweetOrder_id=?1", nativeQuery=true)
	public String gettotalCost(float totalCost);
	

	@Transactional
	@Modifying
	@Query(value="delete from OrderBill o where o.orderBillId =?1")
	public int deletebyId(int orderBillId);


@Query(value="select o from order_bill_table o where o.order_bill_id=?1",nativeQuery=true)
	public OrderBill getOrderBillById(int orderBillId);

/*
@Transactional
@Modifying
//@Query(value="update  order_bill_table  set order_bill_id=?1,created_Date=?2,total_cost=?3,",nativeQuery=true)

@Query(value="update  order_bill_table  set total_cost=?3 where order_bill_id=?1,",nativeQuery=true)
public int updatedOrderBillByOBId(int orderBillId,  float totalCost);
	*/
}