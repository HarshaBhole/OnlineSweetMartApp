package com.cg.onlinesweetmart.exception;

public class CategoryAlreadyExistsException extends Exception {

public CategoryAlreadyExistsException(String str) {
        super(str);
	}
}