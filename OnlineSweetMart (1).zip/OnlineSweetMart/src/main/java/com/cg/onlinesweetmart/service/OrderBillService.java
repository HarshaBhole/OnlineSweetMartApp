package com.cg.onlinesweetmart.service;


import java.util.List;

import com.cg.onlinesweetmart.exception.NoSuchOrderBillException;
import com.cg.onlinesweetmart.exception.OrderBillAlreadyExistsException;
import com.cg.onlinesweetmart.model.OrderBill;

//Abstract class used to group related methods with empty bodies
public interface OrderBillService {
	
    public OrderBill addOrderBill(OrderBill orderBill) throws OrderBillAlreadyExistsException;
   // public OrderBill UpdateOrderBill(OrderBill orderBill);
    public OrderBill UpdateOrderBill(OrderBill orderBill) throws NoSuchOrderBillException;
    
	public OrderBill cancelOrderBill(int orderBillId) throws NoSuchOrderBillException;
	

	List<OrderBill> showAllOrderBills();
	
	public OrderBill extractOrderBillById(int orderBillId);
	
}