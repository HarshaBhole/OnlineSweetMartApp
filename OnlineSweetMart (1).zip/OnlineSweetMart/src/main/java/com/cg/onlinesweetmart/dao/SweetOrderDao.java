package com.cg.onlinesweetmart.dao;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.onlinesweetmart.exception.SweetOrderAlreadyExistsException;
import com.cg.onlinesweetmart.exception.SweetOrderDoesNotExistException;
import com.cg.onlinesweetmart.model.SweetOrder;
import com.cg.onlinesweetmart.repository.SweetOrderRepository;
import com.cg.onlinesweetmart.service.SweetOrderService;

//Service annotation specifies that the annotated class is a service provider. Used at class level.
//this service provider class must override all the methods added in the SweetOrderService interface.
@Service
public class SweetOrderDao implements SweetOrderService {
	// Injecting the repository
	@Autowired
	private SweetOrderRepository sweetOrderRepository;

	// to trace out the error.
	Logger logger = org.slf4j.LoggerFactory.getLogger(CustomerDao.class);

	// this method overrides the addSweetOrder method in SweetOrderService
	// interface.It adds the new sweetOrder into database
	@Override
	public SweetOrder addSweetOrder(SweetOrder sweetOrder) throws SweetOrderAlreadyExistsException {
		// existsById is a method provided by the JpaRepository that checks if there
		// exists an entity with the provided id.
		if (sweetOrderRepository.existsById(sweetOrder.getSweetOrderId())) {
			// Exception Handling
			logger.error("Order id is reserved by some other Order");
			throw new SweetOrderAlreadyExistsException("order id already in use");
		}

		else {
			// save is predefined method of JpaRepository that takes object as input, saves
			// it in, and returns the saved object
			return sweetOrderRepository.save(sweetOrder);
		}

	}

	// This method overrides the update function added in the SweetOrderService
	// interface. this method takes existing object saves it with the changes made.
	@Override
	public SweetOrder updateSweetOrder(SweetOrder sweetOrder) throws SweetOrderDoesNotExistException {
		// Optional is a container object that may contain zero or one element.If the
		// value is not null, isPresent() method returns true.
		Optional<SweetOrder> optional = sweetOrderRepository.findById(sweetOrder.getSweetOrderId());
		if (optional.isPresent()) {
			sweetOrderRepository.save(sweetOrder);
			return sweetOrder;

		}

		else {
			// Exception handling
			logger.error("there is no order with that id");
			throw new SweetOrderDoesNotExistException("order does not exist");
		}

	}

	// Method that implements the delete function. It takes id as the parameter. It
	// internally using existsById meythod predefined in the JpaRepository to check
	// if the object is not null.
	@Override
	public void cancelSweetOrder(int sweetOrderId) throws SweetOrderDoesNotExistException {
		if (sweetOrderRepository.existsById(sweetOrderId)) {
			// getById is also one of the predefined methods of JpaRepository that takes id
			// as a parameter and returns the respective object.
			SweetOrder s = sweetOrderRepository.getById(sweetOrderId);
			// delete(object) is predefined method in JpaRepository that takes object as a
			// parameter and deletes the object, and returns void.
			sweetOrderRepository.delete(s);
		}

		else {
			// Exception handling
			logger.error("there is no order with that id");
			throw new SweetOrderDoesNotExistException("order does not exist");
		}

	}

	// this overriding method returns the list of all the sweetOrders present in the
	// database. It internally uses the findAll method predefined in the
	// JpaRepository
	@Override
	public List<SweetOrder> showAllSweetOrder() {
		// findAll method is predefined in JpaRepository.
		return sweetOrderRepository.findAll();
	}

	// this method returns the total cost associated with the sweetOrder. It uses a
	// user defined query that joins the Product relation and SweetOrder relation
	// and calculates.
	@Override
	public double calculateTotalCost(int sweetOrderId) throws SweetOrderDoesNotExistException {
		// Checking if the object exists or not...
		if (sweetOrderRepository.existsById(sweetOrderId)) {
			return sweetOrderRepository.checkTotalCost(sweetOrderId);

		}

		else {
			// Exception Handling
			logger.error("there is no order with that id");
			throw new SweetOrderDoesNotExistException("order does not exist");
		}

	}

	// Method to extract an Object with Id as a parameter.
	@Override
	public SweetOrder extractSweetOrderById(int sweetOrderId) {
		return sweetOrderRepository.findById(sweetOrderId).get();
	}

}