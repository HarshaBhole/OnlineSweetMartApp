package com.cg.onlinesweetmart.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.onlinesweetmart.dao.UserDao;
import com.cg.onlinesweetmart.exception.NoSuchUserFoundException;
import com.cg.onlinesweetmart.exception.UserAlreadyExistsException;
import com.cg.onlinesweetmart.model.User;

@RestController
@CrossOrigin("*")
//@RequestMapping("/User")
public class UserController {
	Logger logger = org.slf4j.LoggerFactory.getLogger(UserController.class);
	@Autowired
	private UserDao userDao;

	@GetMapping(path = "user/login/{userName}/{password}/{passwordConfirm}")
	public User getUserLogin(@PathVariable String userName, @PathVariable String password,
			@PathVariable String passwordConfirm) {
		return userDao.getLogin(userName, password, passwordConfirm);
	}

	@PostMapping(path = "add/user")
	public User addUser(@Valid @RequestBody User user) throws UserAlreadyExistsException {
		logger.info("User added to the database");
		User u = userDao.addUser(user);
		if (u != null) {

			System.out.println("User is created");
		} else {
			System.out.println("not able to create user object");
		}
		return u;

	}

	@PutMapping(path = "update/user/{userId}")
	public User updateUser(@RequestBody User user, @PathVariable Long userId) {
		logger.info("User details modified successfully");
		return userDao.updateUser(user);
	}

	@GetMapping(path = "fetch/user/{userId}")
	public User getUserById(@PathVariable Long userId) {
		return userDao.extractUserById(userId);
	}

	@DeleteMapping(path = "cancel/User/{id}")
	public User cancelUser(@PathVariable long id) throws NoSuchUserFoundException {
		logger.info("User details removed from the database");
		return userDao.cancelUser(id);
	}

	@GetMapping(path = "get/showAll/Users")
	public List<User> showAllUsers() {
		return userDao.showAllUsers();
	}
}