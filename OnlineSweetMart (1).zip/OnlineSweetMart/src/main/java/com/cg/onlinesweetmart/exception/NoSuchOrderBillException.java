package com.cg.onlinesweetmart.exception;

public class NoSuchOrderBillException extends Exception {
	public NoSuchOrderBillException(String str) {
		super(str);
	}
}