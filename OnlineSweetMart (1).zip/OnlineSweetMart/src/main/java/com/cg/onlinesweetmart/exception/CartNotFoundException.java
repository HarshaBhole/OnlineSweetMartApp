package com.cg.onlinesweetmart.exception;

public class CartNotFoundException extends Exception {

	
	public CartNotFoundException(String msg) {
		super(msg);
	}
	
}
