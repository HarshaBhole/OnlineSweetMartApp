package com.cg.onlinesweetmart.exception;

public class SweetOrderDoesNotExistException extends Exception {
	public SweetOrderDoesNotExistException(String str) {
		super(str);
	}

}