package com.cg.onlinesweetmart.service;

import java.util.List;

import com.cg.onlinesweetmart.exception.NoSuchProductFoundException;
import com.cg.onlinesweetmart.exception.ProductAlreadyExistsException;
import com.cg.onlinesweetmart.model.Product;

public interface ProductService {

	public Product addProduct(Product product) throws ProductAlreadyExistsException;

	public Product cancelProduct(int productId) throws NoSuchProductFoundException;

	List<Product> showAllProducts();

	public Product extractProductById(int productId);

	public Product updateProduct(Product product) throws NoSuchProductFoundException;
}