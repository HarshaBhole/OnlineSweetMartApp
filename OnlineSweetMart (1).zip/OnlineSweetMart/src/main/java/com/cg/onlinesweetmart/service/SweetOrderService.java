package com.cg.onlinesweetmart.service;
import java.util.List;

import com.cg.onlinesweetmart.exception.SweetOrderAlreadyExistsException;
import com.cg.onlinesweetmart.exception.SweetOrderDoesNotExistException;
import com.cg.onlinesweetmart.model.SweetOrder;

public interface SweetOrderService
{
  public SweetOrder addSweetOrder(SweetOrder sweetOrder) throws SweetOrderAlreadyExistsException;
  
  public SweetOrder updateSweetOrder(SweetOrder sweetOrder) throws SweetOrderDoesNotExistException;
  
  public void cancelSweetOrder(int sweetOrderId) throws SweetOrderDoesNotExistException;
  
  public List<SweetOrder> showAllSweetOrder();
  
  public double calculateTotalCost(int sweetOrderId) throws SweetOrderDoesNotExistException;
  
  public SweetOrder extractSweetOrderById(int sweetOrderId);
  

 
}