package com.cg.onlinesweetmart.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Positive;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "cart_table")
@JsonIgnoreProperties({ "hibernateLazyInitializer" })
public class Cart {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int cartId;
	@OneToOne
	@JoinColumn(name = "Product_Id")
	private Product Product;
	//@Column
	//@Positive(message = "ProductCount cannot be zero or negative")
	private int productCount;
	private double total;

	

	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Cart(int cartId, com.cg.onlinesweetmart.model.Product product, int productCount, double total) {
		super();
		this.cartId = cartId;
		Product = product;
		this.productCount = productCount;
		this.total = total;
	}
	

	public Product getProduct() {
		return Product;
	}

	public void setProduct(Product product) {
		Product = product;
	}

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public int getProductCount() {
		return productCount;
	}

	public void setProductCount(int productCount) {
		this.productCount = productCount;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

}