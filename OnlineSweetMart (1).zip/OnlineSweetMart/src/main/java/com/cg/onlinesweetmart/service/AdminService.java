package com.cg.onlinesweetmart.service;
//
//import com.cg.onlinesweetmart.exception.AdminIdAlreadyExistsException;
//import com.cg.onlinesweetmart.exception.AdminNotFoundException;
//import com.cg.onlinesweetmart.model.Admin;
//
//public interface AdminService {
//	
//	public Admin addAdmin(Admin admin) throws AdminIdAlreadyExistsException;
//	public void removeAdmin(String Id) throws AdminNotFoundException;
//	
//
//}
