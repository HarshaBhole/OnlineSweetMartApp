package com.cg.onlinesweetmart.controller;

import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.onlinesweetmart.dao.CartDao;
import com.cg.onlinesweetmart.exception.CartIdAlreadyExistsException;
import com.cg.onlinesweetmart.exception.CartNotFoundException;
import com.cg.onlinesweetmart.exception.NoSuchProductFoundException;
import com.cg.onlinesweetmart.model.Cart;

@RestController
@CrossOrigin("*")

public class CartController {
	Logger logger = org.slf4j.LoggerFactory.getLogger(SweetOrderController.class);

	/*
	 * Injecting cart Service
	 */
	@Autowired
	private CartDao cartDao;

	/*
	 * Adding a new cart
	 */
	@PostMapping(path = "add/cart")
	public Cart addCart(@RequestBody Cart cart) throws CartIdAlreadyExistsException, NoSuchProductFoundException {
		logger.info("cart added to the database");
		return cartDao.addCart(cart);
	}
	
	/*
	 * Updating a cart Throw exception if there is cart  no Not Found Exception;
	 */
	@PutMapping(path = "update/cart/{cartId}")
	public Cart updateCart(@RequestBody Cart cart, @PathVariable int cartId) throws CartNotFoundException {
		logger.info("Cart details modified sucessfully");
		return cartDao.updateCart(cart);
	}

	@GetMapping(path = "fetch/cart/{cartId}")
	public Cart getCartById(@PathVariable int cartId) {
		return cartDao.extractCartById(cartId);
	}

	/*
	 * Deleting a cart Throw exception if there is  Cart no Not Found Exception
	 */

	@DeleteMapping(path = "cancel/cart/{cartId}")
	public int CancelCart(@PathVariable int cartId) throws CartNotFoundException {
		logger.info("Cart details removed from the database");
		return cartDao.cancelCart(cartId);
	}

	/*
	 * Getting from Cart  All  details  from the database 
	 */
	@GetMapping(path = "get/All/cart")
	public List<Cart> showAllCart() {
		logger.info("showAllCart  details  from the database");
		return cartDao.showAllCart();
	}

}
