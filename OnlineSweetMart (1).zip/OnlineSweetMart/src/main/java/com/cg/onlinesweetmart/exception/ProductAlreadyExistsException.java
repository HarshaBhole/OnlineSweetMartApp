package com.cg.onlinesweetmart.exception;

public class ProductAlreadyExistsException extends Exception {

	public ProductAlreadyExistsException() {
		// TODO Auto-generated constructor stub
		super();
	}

	public ProductAlreadyExistsException(String errorMsg) {
		// TODO Auto-generated constructor stub
		super(errorMsg);
	}
}