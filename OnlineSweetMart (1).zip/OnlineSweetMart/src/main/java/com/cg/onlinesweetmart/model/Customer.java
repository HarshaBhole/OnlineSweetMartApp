package com.cg.onlinesweetmart.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Customer_Table")
public class Customer {
	@OneToOne
	private User user;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)

//@Column(name="customer_id")
	// @Range(min=1,message="This field should not be null")
	private int customerId;
	// @NotBlank(message="customerName should not be blank")
	private String customerName;
	// @NotNull(message="This field should not be null")
	private long customerMobile;
	// @NotBlank(message="customerName should not be blank")
	private String customerEmail;
	// @NotBlank(message="customerName should not be blank")
	private String customerAddress;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public long getCustomerMobile() {
		return customerMobile;
	}

	public void setCustomerMobile(long customerMobile) {
		this.customerMobile = customerMobile;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Customer get() {
		// TODO Auto-generated method stub
		return null;
	}

}