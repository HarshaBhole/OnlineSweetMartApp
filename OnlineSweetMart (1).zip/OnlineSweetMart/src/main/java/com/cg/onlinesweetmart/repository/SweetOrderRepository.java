package com.cg.onlinesweetmart.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.cg.onlinesweetmart.model.SweetOrder;

//@Repository is not mandatory as we already declared that the SweetOrderRepository extends JpaRepository
public interface SweetOrderRepository extends JpaRepository<SweetOrder, Integer>
{ 
  @Transactional //Transactional annotation indicates that the annotated method can be done in a transaction 
  @Modifying //enhance the query to be not only for executing SELECT but also for executing INSERT,DELETE and UPDATE
  @Query(value="delete from sweet_order_table s where s.sweet_order_id=(select po.order_product_fk from product_table po inner join sweet_order_table sr on sr.sweet_order_id= po.order_product_fk where sr.sweet_order_id=?1)", nativeQuery=true)
  public void deleteById(int sweetOrderId);
  
  //Query annotation is used to execute the queries. We can give SQL queries as well as the JPQL queries as per our convenience. 
  @Query(value="select sum(p.price) from sweet_order_table s inner join product_table p ON p.order_product_fk = s.sweet_order_id where s.sweet_order_id=?1", nativeQuery=true)
  public double checkTotalCost(int sweetOrderId);
  
  @Query(value="select s from sweet_order_table s where s.sweet_order_id=?1",nativeQuery=true)
  public SweetOrder getOrderById(int Id);



 
}