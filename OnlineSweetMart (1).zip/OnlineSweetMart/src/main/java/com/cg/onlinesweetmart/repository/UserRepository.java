package com.cg.onlinesweetmart.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.onlinesweetmart.model.User;
@Repository
public interface UserRepository extends JpaRepository<User, Long> {
	
//	@Query(value= "select u.user_userId from user_table u inner join admin_table ad on ad.user_id=u.user_id where ad.admin_id=?1", nativeQuery=true)
//	public String getUserId(int userId);
//	@Query(value= "select u.user_name from user_table u inner join admin_table ad on ad.user_id=u.user_id where ad.admin_id=?1", nativeQuery=true)
//	public String getUserName(int userId);
//	@Query(value="select u.user_password from user_table u inner join admin_table ad on ad.user_id=u.user_id where ad.admin_id=?1", nativeQuery=true)
//	public String getUserPassword(int userId);
//	@Query(value="select u.user_confirmpassword from user_table u inner join admin_table ad on ad.user_id=u.user_id where ad.admin_id=?1", nativeQuery=true)
//	public String getUserConfirmPassword(int userId);
//	@Query(value="select u.user_type from user_table u inner join admin_table ad on ad.user_id=u.user_id where ad.admin_id=?1", nativeQuery=true)
//    public String getUserType(int adminId);
	
	//@Query(value="delete from User u where u.userId=?1")
	//public int deletebyId(Long userId);	
	
	@Query(value="select u from User u where u.userName=?1 and u.password=?2 and u.passwordConfirm=?3 ")
	public User getLogin(String userName,String password,String passwordConfirm);
	@Transactional
	@Modifying
	
	
	@Query(value="update  user_table  set user_name=?1,password=?2,password_confirm=?3,type=?4 where user_id=?5",nativeQuery=true)
	
	public int updatedUserByUId(String userName,String password,String passwordConfirm, String type,Long userId);
	
	

@Query(value="select u from user_table u where u.user_id=?1",nativeQuery=true)
	public User getUserById(Long userId);
} 