package com.cg.onlinesweetmart.model;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "order_Bill_table")
public class OrderBill {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
//@Range(min=1,message="orderBillId should not be Null")
	private int orderBillId;

	@JsonFormat(pattern = "yyyy-MM-dd")

//@NotBlank(message="createdDate should not be Null")
	private LocalDate createdDate;
	private float totalCost;

//Parent entity is ... then child entity also ...
	@OneToMany(targetEntity = SweetOrder.class, cascade = CascadeType.ALL)
	@JoinColumn(name = "orderbillOrder_fk", referencedColumnName = "orderBillId")
	private List<SweetOrder> listSweetOrder;

	public int getOrderBillId() {
		return orderBillId;
	}

	public void setOrderBillId(int orderBillId) {
		this.orderBillId = orderBillId;
	}

	public LocalDate getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;
	}

	public float getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(float totalCost) {
		this.totalCost = totalCost;
	}

	public List<SweetOrder> getListSweetOrder() {
		return listSweetOrder;
	}

	public void setListSweetOrder(List<SweetOrder> listSweetOrder) {
		this.listSweetOrder = listSweetOrder;
	}

}