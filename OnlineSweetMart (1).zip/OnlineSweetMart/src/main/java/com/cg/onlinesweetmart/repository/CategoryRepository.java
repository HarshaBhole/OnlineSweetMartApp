package com.cg.onlinesweetmart.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.onlinesweetmart.model.Category;

@Repository
public interface CategoryRepository extends JpaRepository<Category, Integer> {

	@Query(value = "select sum(p.price) from Category_table c inner join Product_table p ON p.category_id=c.category_id where c.category_id=?1", nativeQuery = true)
	public double calculateTotalCost(int categoryId);

	@Transactional
	@Modifying
	@Query(value = "update category_table set name=?1 where category_id=?2", nativeQuery = true)
	public int updatedCategoryByCgId(String name, int categoryId);

	@Query(value = "select c from category_table c where c.category_id=?1", nativeQuery = true)
	public Category getCategoryById(int categoryId);
}