package com.cg.onlinesweetmart.exception;

public class NoSuchCategoryFoundException extends Exception {

	public NoSuchCategoryFoundException(String str) {
		super(str);
	}
}