package com.cg.onlinesweetmart.dao;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.onlinesweetmart.exception.NoSuchProductFoundException;
import com.cg.onlinesweetmart.exception.ProductAlreadyExistsException;
import com.cg.onlinesweetmart.model.Product;
import com.cg.onlinesweetmart.repository.ProductRepository;
import com.cg.onlinesweetmart.service.ProductService;

@Service
public class ProductDao implements ProductService {

	@Autowired
	private ProductRepository productRepos;

	Logger logger = org.slf4j.LoggerFactory.getLogger(ProductDao.class);

	@Override
	public Product updateProduct(Product product) throws NoSuchProductFoundException {
		Optional<Product> optional = productRepos.findById(product.getProductId());
		if (optional.isPresent()) {
			productRepos.save(product);
			return product;
		} else {
			throw new NoSuchProductFoundException("Product couldn't be Updated! ");
		}
	}

	@Override
	public Product cancelProduct(int productId) throws NoSuchProductFoundException {
		// TODO Auto-generated method stub
		Optional<Product> product = productRepos.findById(productId);
		Product p = null;
		if (product.isPresent()) {
			p = product.get();
			productRepos.delete(p);
		} else {
			throw new NoSuchProductFoundException("No such Product Exists");
		}
		return p;
	}

	@Override
	public List<Product> showAllProducts() {
		// TODO Auto-generated method stub
		return productRepos.findAll();
	}

	@Override
	public Product extractProductById(int productId) {
		// TODO Auto-generated method stub
		return productRepos.findById(productId).get();
	}

	@Override
	public Product addProduct(Product product) throws ProductAlreadyExistsException {

		if (productRepos.existsById(product.getProductId())) {
			logger.error("Product had already registered ");
			throw new ProductAlreadyExistsException("Product already exists ");
		} else {
			logger.info("user added successfully");
			return productRepos.save(product);
		}
	}
}