package com.cg.onlinesweetmart.exception;

public class NoSuchUserFoundException extends Exception {

	public NoSuchUserFoundException(String msg) {
		super(msg);
	}

}
