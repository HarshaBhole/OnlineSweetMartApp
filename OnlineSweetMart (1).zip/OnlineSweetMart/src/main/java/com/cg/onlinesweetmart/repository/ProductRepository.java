package com.cg.onlinesweetmart.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.onlinesweetmart.model.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> { 
		
		
		@Query(value= "select p.product_Id from product_table p inner join admin_table ad on ad.product_id=p.product_id where ad.admin_id=?1", nativeQuery=true)
		public String getProductId(int productId);
		@Query(value= "select p.product_name from product_table p inner join admin_table ad on ad.product_id=p.product_id where ad.admin_id=?1", nativeQuery=true)
		public String getName(int productId);
		@Query(value="select p.product_photoPath from product_table p inner join admin_table ad on ad.product_id=p.product_id where ad.admin_id=?1", nativeQuery=true)
		public String getPhotoPath(int productId);

		@Query(value="select p.product_description from product_table p inner join admin_table ad on ad.product_id=p.product_id where ad.admin_id=?1", nativeQuery=true)
		public String getDescription(int productId);
		@Query(value="select p.product_available from product_table p inner join admin_table ad on ad.product_id=p.product_id where ad.admin_id=?1", nativeQuery=true)
		public String getAvailable(int productId);
		@Query(value="select p.product_category from product_table p inner join admin_table ad on ad.product_id=p.product_id where ad.admin_id=?1", nativeQuery=true)
	    public String getCategory(int adminId);

		@Query(value="select p from product_table p where p.product_id=?1",nativeQuery=true)
		public Product getProductById(int productId);
	
		
}