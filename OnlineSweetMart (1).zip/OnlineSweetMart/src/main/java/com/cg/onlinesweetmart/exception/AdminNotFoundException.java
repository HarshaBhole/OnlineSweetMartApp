package com.cg.onlinesweetmart.exception;

//
//public class AdminNotFoundException extends Exception {
//
//	public AdminNotFoundException(String msg) {
//		super(msg);
//	}
//}