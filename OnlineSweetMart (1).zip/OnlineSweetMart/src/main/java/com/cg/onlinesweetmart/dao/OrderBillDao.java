package com.cg.onlinesweetmart.dao;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.onlinesweetmart.exception.NoSuchOrderBillException;
import com.cg.onlinesweetmart.exception.OrderBillAlreadyExistsException;
import com.cg.onlinesweetmart.model.OrderBill;
import com.cg.onlinesweetmart.repository.OrderBillRepository;
import com.cg.onlinesweetmart.service.OrderBillService;

//register cls in spring framework
@Service
public class OrderBillDao implements OrderBillService {

	//
	@Autowired
	private OrderBillRepository orderBillRepos;

	// Logger for Specific msg for system
	Logger logger = org.slf4j.LoggerFactory.getLogger(OrderBillDao.class);

	@Override
	public OrderBill addOrderBill(OrderBill orderBill) throws OrderBillAlreadyExistsException {

		if (orderBillRepos.existsById(orderBill.getOrderBillId())) {
			logger.error("OrderBill already exists exception");
			throw new OrderBillAlreadyExistsException("OrderBill already exists");
		} else {
			logger.info("OrderBill added successfully");
			return orderBillRepos.save(orderBill);
		}
	}

	@Override
	public OrderBill UpdateOrderBill(OrderBill orderBill) throws NoSuchOrderBillException {
		Optional<OrderBill> optional = orderBillRepos.findById(orderBill.getOrderBillId());
		if (optional.isPresent()) {
			orderBillRepos.save(orderBill);
			return orderBill;
		} else {
			throw new NoSuchOrderBillException("OrderBill couldn't be Updated!");
		}
	}

	/*
	 * @Override public OrderBill UpdateOrderBill(OrderBill orderBill)throws
	 * NoSuchOrderBillException {
	 * 
	 * if(orderBillRepos.existsById(orderBill.getOrderBillId())) {
	 * logger.info("OrderBill updated successfully"); return
	 * orderBillRepos.save(orderBill); } else {
	 * logger.error("No such OrderBill exists exception"); throw new
	 * NoSuchOrderBillException("OrderBill does not exist"); } }
	 * 
	 */
	@Override
	public OrderBill cancelOrderBill(int OrderBillId) throws NoSuchOrderBillException {

		OrderBill o = orderBillRepos.getById(OrderBillId);
		int status = orderBillRepos.deletebyId(OrderBillId);
		if (status == 1) {
			return o;
		}
		return null;
	}

	@Override
	public List<OrderBill> showAllOrderBills() {
		// TODO Auto-generated method stub
		return orderBillRepos.findAll();
	}
	/*
	 * @Override public OrderBill UpdateOrderBill(OrderBill orderbill) { int
	 * status=0; int OBId= orderbill.getOrderBillId(); float
	 * Cost=orderbill.getTotalCost(); //List<SweetOrder>
	 * listSweetOrder=orderbill.getListSweetOrder();
	 * 
	 * status=orderBillRepos.updatedOrderBillByOBId(OBId,Cost); if(status>=1) {
	 * return orderbill; }else { return null; } }
	 */

	@Override
	public OrderBill extractOrderBillById(int orderBillId) {
		// TODO Auto-generated method stub
		return orderBillRepos.findById(orderBillId).get();

	}

}