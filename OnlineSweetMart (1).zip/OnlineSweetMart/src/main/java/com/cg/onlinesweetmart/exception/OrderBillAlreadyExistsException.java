package com.cg.onlinesweetmart.exception;

public class OrderBillAlreadyExistsException extends Exception {
	public OrderBillAlreadyExistsException(String str) {
		super(str);
	}
}