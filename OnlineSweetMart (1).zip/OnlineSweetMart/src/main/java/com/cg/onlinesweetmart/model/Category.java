package com.cg.onlinesweetmart.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

@Entity
@Table(name = "category_table")
public class Category {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	// @Range(min=1,message="category Id Should not be null")
	private int categoryId;
	@NotBlank(message = "category Name Should not be null")
	private String name;

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}