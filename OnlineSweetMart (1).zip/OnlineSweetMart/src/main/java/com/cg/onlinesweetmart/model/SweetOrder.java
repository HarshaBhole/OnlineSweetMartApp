

package com.cg.onlinesweetmart.model;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="sweetOrder_table")
public class SweetOrder {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int sweetOrderId;
	@OneToOne
	private User user;
	
	private LocalDate createdDate;

	@OneToMany(fetch = FetchType.LAZY)
    private Map<Long , Product> groupedProducts;
    
	public int getSweetOrderId() {
		return sweetOrderId;
	}
	public void setSweetOrderId(int sweetOrderId) {
		this.sweetOrderId = sweetOrderId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public LocalDate getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;
	}
//	public Customer getCustomer() {
//		return customer;
//	}
	
	public Map<Long ,Product> getGroupedProducts() {
		return groupedProducts;
	}
	public void setGroupedProducts(Map<Long,Product> groupedProducts) {
		this.groupedProducts = groupedProducts;
	}
//	public void setCustomer(Customer customer) {
//		this.customer = customer;
//	}
	 
}
