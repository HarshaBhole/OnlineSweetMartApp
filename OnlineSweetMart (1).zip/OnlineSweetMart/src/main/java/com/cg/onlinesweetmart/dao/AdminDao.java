package com.cg.onlinesweetmart.dao;
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.cg.onlinesweetmart.exception.AdminIdAlreadyExistsException;
//import com.cg.onlinesweetmart.exception.AdminNotFoundException;
//import com.cg.onlinesweetmart.model.Admin;
//import com.cg.onlinesweetmart.repository.AdminRepository;
//import com.cg.onlinesweetmart.service.AdminService;
//
//@Service
//public class AdminDao implements AdminService {
//
//	@Autowired
//	private AdminRepository adminrepo;
//
//	@Override
//	public Admin addAdmin(Admin admin) throws AdminIdAlreadyExistsException {
//
//		Optional<Admin> ispresent = adminrepo.findById(admin.getId());
//		System.out.println(ispresent);
//
//		if (ispresent.isPresent())
//			throw new AdminIdAlreadyExistsException("Admin already exists!");
//		else
//			return adminrepo.save(admin);
//
//	}
//
//	@Override
//	public void removeAdmin(String Id) throws AdminNotFoundException {
//
//	        
//		Optional<Admin> ispresent = adminrepo.findById(Id);
//		if (!ispresent.isPresent())
//			throw new AdminNotFoundException("Admin not found!");
//		else {
//			 adminrepo.deleteById(Id);
//         
//		}
//			
//	}
//	}
//
//
