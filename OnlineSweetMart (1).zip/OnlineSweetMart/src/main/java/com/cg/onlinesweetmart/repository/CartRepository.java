package com.cg.onlinesweetmart.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.cg.onlinesweetmart.model.Cart;

public interface CartRepository extends JpaRepository<Cart, Integer> {

	@Transactional
	@Modifying
	@Query(value = "delete from Cart c where c.cartId=?1")
	public int deletebyId(int cartId);

	@Query(value = "select sum(p.price) from Cart_table c inner join Product_table p ON p.cart_id=c.cart_id where c.cart_id=?1", nativeQuery = true)
	public double grandTotal(int cartId);

	@Query(value = "select c from cart_table c where c.cart_id=?1", nativeQuery = true)
	public Cart getCartById(int cartId);

	@Query(value = "update cart_table  set product_count=?1 , total=total/product_count*?1 where cart_id=?2", nativeQuery = true)
	public int updatedCartByCId(int productcount, int cartId);

}
