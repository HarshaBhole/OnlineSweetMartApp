package com.cg.onlinesweetmart.exception;

public class CartIdAlreadyExistsException extends  Exception {
   
	
	public CartIdAlreadyExistsException(String msg)
	{
		super(msg);
	}
}
