package com.cg.onlinesweetmart.repository;
//
//import javax.transaction.Transactional;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Modifying;
//import org.springframework.data.jpa.repository.Query;
//
//import com.cg.onlinesweetmart.model.Admin;
//
//public interface AdminRepository  extends JpaRepository< Admin , String>{
//
//	
//	@Transactional
//	@Modifying
//	@Query(value="delete from Admin a where a.Id=?1")
//	public int removeadmin(String Id);
//	
//
//
//}
