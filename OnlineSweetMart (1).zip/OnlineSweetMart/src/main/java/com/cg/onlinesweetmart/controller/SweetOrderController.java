package com.cg.onlinesweetmart.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.onlinesweetmart.dao.SweetOrderDao;
import com.cg.onlinesweetmart.exception.SweetOrderAlreadyExistsException;
import com.cg.onlinesweetmart.exception.SweetOrderDoesNotExistException;
import com.cg.onlinesweetmart.model.SweetOrder;
import com.cg.onlinesweetmart.repository.SweetOrderRepository;

//for HTTP requests.
@CrossOrigin("*")
//for making restful web services.Used at class level.
@RestController
public class SweetOrderController {

	// Injecting the service implementation class into controller class.
	@Autowired
	private SweetOrderDao sweetOrderDao;
	// Injecting Repository
	@Autowired
	private SweetOrderRepository sweetOrderRepository;

	// to trace out the error.
	Logger logger = (Logger) org.slf4j.LoggerFactory.getLogger(SweetOrderController.class);

	// PostMapping handles the HTTP POST requests. Shortcut for
	// @RequestMapping(method=RequestMethod.POST).
	@PostMapping(path = "add/SweetOrder") // specifying the path for add service
	public SweetOrder addSweetOrder(@Valid @RequestBody SweetOrder sweetOrder) throws SweetOrderAlreadyExistsException {
		SweetOrder s = sweetOrderDao.addSweetOrder(sweetOrder);
		if (s != null) {
			System.out.println("Order is created");
		} else {
			System.out.println("unable to create order");
		}

		return sweetOrder;
	}

	// GetMapping handles the HTTP GET requests.It fetches single or multiple
	// resources based on the request. Shortcut for
	// @RequestMapping(method=RequestMethod.GET)
	@GetMapping(path = "get/All/SweetOrder")
	public List<SweetOrder> showAllSweetOrder() {
		return sweetOrderDao.showAllSweetOrder();

	}

	// PutMapping is used to update/modify the resource based on the request. can
	// also be expanded as @RequestMapping(method=RequestMethod.PUT)
	@PutMapping(path = "update/SweetOrder/{sweetOrderId}")
	// @RequestBody indicates that the sweetOrder should be bind to the HTTP
	// request. @PathVariable annotation indicates that the variable sweetOrderId is
	// the parameter to the method.
	public SweetOrder updateSweetOrder(@RequestBody @Valid SweetOrder sweetOrder, @PathVariable int sweetOrderId)
			throws SweetOrderDoesNotExistException {
		logger.info("Order details updated successfully");
		return sweetOrderDao.updateSweetOrder(sweetOrder);

	}

	// DeleteMapping annotation is used to delete the resource entity. Can also be
	// written as RequestMapping(method=RequestMethod.DELETE)
	@DeleteMapping(path = "cancel/SweetOrder/{sweetOrderId}") // path for delete
	public void cancelSweetOrder(@PathVariable("sweetOrderId") int sweetOrderId)
			throws SweetOrderDoesNotExistException {
		sweetOrderDao.cancelSweetOrder(sweetOrderId);
	}

	// This method calculates the total cost of an order based on the id hence, The
	// PathVariable is sweetOrderId here.
	@GetMapping(path = "calculateTotalCost/{sweetOrderId}")
	public double calculateTotalCost(@PathVariable int sweetOrderId) throws SweetOrderDoesNotExistException {
		return sweetOrderDao.calculateTotalCost(sweetOrderId);

	}

	// This method gets the particular entity of SweetOrder based on the Id which is
	// a PathVariable.
	@GetMapping(path = "fetch/SweetOrder/{sweetOrderId}")
	public SweetOrder getOrderById(@PathVariable int sweetOrderId) {
		return sweetOrderDao.extractSweetOrderById(sweetOrderId);
	}

}