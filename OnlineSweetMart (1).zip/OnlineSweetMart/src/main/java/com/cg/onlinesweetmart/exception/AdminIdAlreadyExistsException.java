package com.cg.onlinesweetmart.exception;
//
//public class AdminIdAlreadyExistsException extends Exception {
//
//	public AdminIdAlreadyExistsException(String msg) {
//		super(msg);
//	}
//
//}
