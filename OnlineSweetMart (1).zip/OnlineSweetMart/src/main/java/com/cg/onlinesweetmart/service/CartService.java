package com.cg.onlinesweetmart.service;

import java.util.List;

import com.cg.onlinesweetmart.exception.CartIdAlreadyExistsException;
import com.cg.onlinesweetmart.exception.CartNotFoundException;
import com.cg.onlinesweetmart.exception.NoSuchProductFoundException;
import com.cg.onlinesweetmart.model.Cart;

public interface CartService {

	public Cart addCart(Cart cart) throws NoSuchProductFoundException, CartIdAlreadyExistsException;

	public Cart updateCart(Cart cart) throws CartNotFoundException;

	public int cancelCart(int cartId) throws CartNotFoundException;

	public List<Cart> showAllCart();

	public Cart extractCartById(int cartId);

}
