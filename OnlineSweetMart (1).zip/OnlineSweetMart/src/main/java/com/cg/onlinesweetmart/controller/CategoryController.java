package com.cg.onlinesweetmart.controller;

import java.util.List;


import javax.validation.Valid;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.onlinesweetmart.dao.CategoryDao;
import com.cg.onlinesweetmart.exception.CategoryAlreadyExistsException;
import com.cg.onlinesweetmart.exception.NoSuchCategoryException;
import com.cg.onlinesweetmart.model.Category;

@CrossOrigin("*")
@RestController
//@RequestMapping("/Category")
public class CategoryController {
	Logger logger = org.slf4j.LoggerFactory.getLogger(CategoryController.class);

	@Autowired
	private CategoryDao dao;

	@PostMapping(path = "add/Category")
	public Category addCategory(@Valid @RequestBody Category c) throws CategoryAlreadyExistsException {
		logger.info("category added to the database");
		Category c1 = dao.addCategory(c);
		if (c1 != null) {

			System.out.println("category is created");
		} else {
			System.out.println("not able to create category object");
		}
		return c1;
	}

	@PutMapping(path = "update/category/{categoryId}")
	public Category updatedCategory(@RequestBody Category category, @PathVariable int categoryId) {
		return dao.updateCategory(category);
	}

	@DeleteMapping(path = "cancel/Category/{categoryId}")

	public Category cancelCategory(@PathVariable int categoryId) throws NoSuchCategoryException {
		logger.info("category details removed from the database");
		return dao.cancelCategory(categoryId);

	}

	@GetMapping(path = "get/All/Category")
	public List<Category> showAllCategorys() {

		return dao.showAllCategorys();
	}

	@GetMapping(path = "calculate/Totalcost/{categoryId}")
	public double calculateTotalCost(@PathVariable int categoryId) {
		return dao.calculateTotalCost(categoryId);
	}

	@GetMapping(path = "fetch/category/{categoryId}")
	public Category getCategoryById(@PathVariable int categoryId) {
		return dao.extractCategoryById(categoryId);
	}
}