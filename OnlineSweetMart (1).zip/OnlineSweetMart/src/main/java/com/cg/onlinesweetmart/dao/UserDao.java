package com.cg.onlinesweetmart.dao;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.onlinesweetmart.exception.NoSuchUserFoundException;
import com.cg.onlinesweetmart.exception.UserAlreadyExistsException;
import com.cg.onlinesweetmart.model.User;
import com.cg.onlinesweetmart.repository.UserRepository;
import com.cg.onlinesweetmart.service.UserService;

@Service
public class UserDao  implements UserService{
	

	@Autowired
	private UserRepository userRepos;
	
	Logger logger=org.slf4j.LoggerFactory.getLogger(UserDao.class);
	
	@Override
	
	public User addUser(User user)throws UserAlreadyExistsException {
			if (userRepos.existsById(user.getUserId())) {
				logger.error("User had already registered ");
				throw new UserAlreadyExistsException("User already exists ");
			} else {
				logger.info("user added successfully");
				return userRepos.save(user);
			}
		}
	
	
	
  	@Override
	public User updateUser(User user)
  	{

		
			
			int status=0;
			Long uId=user.getUserId();
			String name=user.getUserName();
			
			String password=user.getPassword();
			String passwordConfirm=user.getPasswordConfirm();
			String type=user.getType();
			
			status=userRepos.updatedUserByUId(name,password,passwordConfirm,type,uId);
			if(status>=1) {
				return user;
			}else {
			return null;
			}
		}
	

	


	@Override
	public List<User> showAllUsers() {
		// TODO Auto-generated method stub
		return userRepos.findAll();
	}

	@Override
	public User cancelUser(Long userId) throws NoSuchUserFoundException {
		
	       Optional<User> user = userRepos.findById(userId);  
	        User cust = null;          
	        if (user.isPresent()) {
	            cust = user.get();                  
	            userRepos.delete(cust);
	        }else {
	            throw new NoSuchUserFoundException("No such User Exists");
	        }  
	        return cust;
	   
	}



	@Override
	public User getLogin(String userName,String password,String passwordConfirm) {
		return userRepos.getLogin(userName,password,passwordConfirm);
	}



	@Override
	public User extractUserById(Long userId) {
		return userRepos.findById(userId).get();
		
	}
	
}