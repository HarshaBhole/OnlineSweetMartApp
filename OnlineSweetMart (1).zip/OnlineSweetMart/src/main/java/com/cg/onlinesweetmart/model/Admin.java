package com.cg.onlinesweetmart.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "admin_table")
@JsonIgnoreProperties({ "hibernateLazyInitializer" })
public class Admin {

	@Id
	private String Id;
	@NotEmpty(message = "password should not empty")
	private String password;

	@OneToOne
	@JoinColumn(name = "customerId")
	private Customer customer;

	@OneToOne
	@JoinColumn(name = "userId")
	private User user;

	
	@OneToOne
	@JoinColumn(name = "categoryId")
	private Category category;

	@OneToOne
	@JoinColumn(name = "cartId")
	public Cart cart;

	@OneToOne
	@JoinColumn(name = "productId")
	public Product product;

	public Admin() {
		super();
	
	}

	public Admin(String id, String password, Customer customer, User user, Category category,
			Cart cart, Product product) {
		super();
		Id = id;
		this.password = password;
		this.customer = customer;
		this.user = user;
		this.category = category;
		this.cart = cart;
		this.product = product;
	}

}