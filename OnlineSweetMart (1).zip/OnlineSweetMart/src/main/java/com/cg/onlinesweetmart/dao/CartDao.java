package com.cg.onlinesweetmart.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.onlinesweetmart.exception.CartIdAlreadyExistsException;
import com.cg.onlinesweetmart.exception.CartNotFoundException;
import com.cg.onlinesweetmart.exception.NoSuchProductFoundException;
import com.cg.onlinesweetmart.model.Cart;
import com.cg.onlinesweetmart.model.Product;
import com.cg.onlinesweetmart.repository.CartRepository;
import com.cg.onlinesweetmart.repository.ProductRepository;
import com.cg.onlinesweetmart.service.CartService;

@Service
public class CartDao implements CartService {

	@Autowired
	private CartRepository cartrepo;

	@Autowired
	private ProductRepository prodrepo;

	@Override
	public Cart addCart(Cart cart) throws NoSuchProductFoundException, CartIdAlreadyExistsException {

		Optional<Product> productpresent = prodrepo.findById(cart.getProduct().getProductId());

		double productprice = productpresent.get().getPrice();

		Optional<Cart> ispresent = cartrepo.findById(cart.getCartId());

		Optional<Product> ispresent2 = prodrepo.findById(cart.getProduct().getProductId());

		if (ispresent.isPresent())
			throw new CartIdAlreadyExistsException("Cart already exists!");
		else if (!ispresent2.isPresent())
			throw new NoSuchProductFoundException(" Product  Not Found !");

		else {
			cart.setTotal(cart.getProductCount() * productprice);
			return cartrepo.save(cart);
		}
	}

	@Override
	public Cart extractCartById(int cartId) {
		// TODO Auto-generated method stub
		return cartrepo.findById(cartId).get();
	}

	@Override
	public Cart updateCart(Cart cart) {

		int status = 0;
		int cId = cart.getCartId();
		int pcount = cart.getProductCount();
		status = cartrepo.updatedCartByCId(pcount, cId);
		if (status >= 1) {
			return cart;
		} else {
			return null;
		}
	}

	@Override
	public int cancelCart(int cartId) throws CartNotFoundException {

		Optional<Cart> ispresent = cartrepo.findById(cartId);
		if (!ispresent.isPresent())
			throw new CartNotFoundException("Cart not found!");
		else {
			int status = cartrepo.deletebyId(cartId);
			return status;
		}
	}

	@Override
	public List<Cart> showAllCart() {
		return cartrepo.findAll();
	}

}
