package com.cg.onlinesweetmart.service;






import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cg.onlinesweetmart.dao.CartDao;
import com.cg.onlinesweetmart.model.Cart;
import com.cg.onlinesweetmart.model.Category;
import com.cg.onlinesweetmart.model.Product;
import com.cg.onlinesweetmart.repository.CartRepository;
@ExtendWith(MockitoExtension.class)
public class CartServiceTest {

	
	


	@InjectMocks
	private CartDao cservice;
	@Mock
	private CartRepository cartrepo;

	@Test
	 void test_addcart() throws Exception{
	
		Cart s1 = new Cart(1,1,0.0 new Product(1,"product_name",0.0,"description","yes" ,"img") new Category(1, "Category_name" )));
		Mockito.when(cartrepo.save(s1)).thenReturn(s1);
		Cart result = cartrepo.save(s1);
		assertEquals(1, result.getCartId());
	}
	
	
	
	
	@Test
	 void test_updatecart() throws Exception{

		Cart s1 = new Cart(1,1,0.0 new Product(1,"product_name",0.0,"description","yes" ,"img") new Category(1, "Category_name" )));
	
		s1.setCartId(2);
		
		Mockito.when(cartrepo.save(s1)).thenReturn(s1);
		Cart result = cartrepo.save(s1);
		
		assertNotEquals(1, result.getCartId());
	}
	
	
	
	@Test
	 void test_cancelCart() throws Exception {

		Cart s1 = new Cart(1,1,0.0 new Product(1,"product_name",0.0,"description","yes" ,"img") new Category(1, "Category_name" )));
		//when(cartrepo.existsById(s.getCartId())).thenReturn(true);
		cservice.cancelCart(s.getCartId());
		verify(cartrepo).deletebyId(1);
	}
	
	@Test
	 void test_showAllCart() throws Exception {
		Product p = new Product(1,"product_name","Photopath",0.0,"description",true, new Category(1, "Category_name"));	
		Product p2 = new Product(2,"product_name","Photopath",0.0,"description",true, new Category(1, "Category_name"));	
		List<Product> plist = new ArrayList<Product>();
		plist.add(p2);
		plist.add(p);
	     new Cart(1,0, plist,0,0.0);
		Mockito.when(cartrepo.findAll())
				.thenReturn(Stream.of(new Cart(1,0, plist,0,0.0), new Cart( 2,0, plist,0,0.0)).collect(Collectors.toList()));
		assertEquals(2, cservice.showAllCart().size());
	}

	
}
	
	